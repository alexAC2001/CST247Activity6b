﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegisterLoginAct2.Utility
{
    public class MyLogger : Ilogger
    {
        // A singleton is a class that can have only exactly 1 instance
        // Having a singleton guarantees that there is exactly 1 instance of this logger running at any time in our application

        private static MyLogger instance;
        private static Logger logger;

        public static MyLogger GetInstance()
        {
            if (instance == null)    // If we don't have an instance, we'll make one
            {
                instance = new MyLogger();
            }
            return instance;    // If we already have one, we'll resuse it
        }        
        public Logger GetLogger()
        {
            if (MyLogger.logger == null)
                MyLogger.logger = LogManager.GetLogger("RegisterLoginAppRule"); // Rule from config file
            return MyLogger.logger;
        }

        public void Debug(string message)
        {
            GetLogger().Debug(message);
        }

        public void Error(string message)
        {
            GetLogger().Error(message);
        }

        public void Info(string message)
        {
            GetLogger().Info(message);
        }

        public void Warning(string message)
        {
            GetLogger().Warn(message);
        }
    }
}
