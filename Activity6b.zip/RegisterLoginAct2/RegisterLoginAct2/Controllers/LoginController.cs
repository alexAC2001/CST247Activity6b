﻿using Microsoft.AspNetCore.Mvc;
using NLog;
using RegisterLoginAct2.Models;
using RegisterLoginAct2.Services;
using RegisterLoginAct2.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegisterLoginAct2.Controllers
{
    public class LoginController : Controller
    {
        // We no don't have to declare this item since we have a singleton in the MyLogger file
        //private static Logger logger = LogManager.GetLogger("RegisterLoginAppRule"); // now it knows where it will log to

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ProcessLogin(UserModel user)
        {
            MyLogger.GetInstance().Info("Processing a login attempt");
            MyLogger.GetInstance().Info(user.toString()); // from the UserModel

            SecurityService securityService = new SecurityService();

            if (securityService.IsValid(user))
            {
                MyLogger.GetInstance().Info("Login Success");
                return View("LoginSuccess", user);
            }
            else
            {
                MyLogger.GetInstance().Warning("Login failure");
                return View("LoginFailure", user);
            }
               
        }
    }
}
